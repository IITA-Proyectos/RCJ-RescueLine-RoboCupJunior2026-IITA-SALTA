# Roboliga 2025 > zonas alta
https://universe.roboflow.com/enzzorobotics/roboliga-2025-kh2ly

Provided by a Roboflow user
License: Public Domain

